const $ = id => document.getElementById(id);
async function api(url, options={}) {
  const response = await fetch(url, { credentials:"same-origin", ...options });
  const data = await response.json().catch(()=>({}));
  if (!response.ok) throw new Error(data.error || "Something went wrong.");
  return data;
}
function showApp(on) { $("login").classList.toggle("hidden",on); $("app").classList.toggle("hidden",!on); }
async function refreshFiles() {
  $("files").textContent = "Loading…";
  try {
    const data = await api("/api/files");
    $("files").innerHTML = "";
    if (!data.files.length) { $("files").textContent = "No images uploaded yet."; return; }
    data.files.forEach(file => {
      const card = document.createElement("div"); card.className="file";
      const a = document.createElement("a"); a.href=file.url; a.target="_blank"; a.rel="noopener"; a.textContent="Download image";
      const small = document.createElement("small"); small.textContent=file.path;
      card.append(a,small); $("files").append(card);
    });
  } catch(e) { $("files").textContent=e.message; }
}
async function check() {
  try { const data=await api("/api/me"); showApp(data.authenticated); if(data.authenticated) refreshFiles(); }
  catch { showApp(false); }
}
$("loginForm").addEventListener("submit", async e => {
  e.preventDefault(); $("loginMsg").textContent="Checking…";
  try { await api("/api/login",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({password:$("password").value})}); $("password").value=""; $("loginMsg").textContent=""; showApp(true); refreshFiles(); }
  catch(err) { $("loginMsg").textContent=err.message; }
});
$("logout").onclick=async()=>{await api("/api/logout",{method:"POST"});showApp(false);};
$("refresh").onclick=refreshFiles;
$("photos").onchange=()=>{
  const files=[...$("photos").files]; $("selected").textContent=files.length?`${files.length} image(s) selected`:"No images selected";
  $("upload").disabled=!files.length;
};
$("upload").onclick=async()=>{
  const files=[...$("photos").files]; if(!files.length)return;
  const form=new FormData(); files.forEach(f=>form.append("photos",f));
  $("upload").disabled=true; $("uploadMsg").textContent="Uploading…";
  try { const result=await api("/api/upload",{method:"POST",body:form}); $("uploadMsg").textContent=`Uploaded ${result.uploaded} image(s) successfully.`; $("photos").value=""; $("selected").textContent="No images selected"; await refreshFiles(); }
  catch(e) {$("uploadMsg").textContent=e.message;}
  finally {$("upload").disabled=false;}
};
check();

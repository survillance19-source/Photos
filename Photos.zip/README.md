# Private Photo Transfer

A small password-protected web portal for transferring work images from a phone to an office PC without logging into WhatsApp, Google Drive, or Telegram on the office PC.

## Important network point

The phone and office PC do **not** need to be on the same Wi-Fi. Both open the same hosted HTTPS website. The app stores images in a **private Supabase Storage bucket** and creates short-lived (10-minute) download links after portal authentication.

## Before using it

- Get approval from your company/IT team before uploading company or customer images to any third-party cloud.
- Do not use this for confidential/customer images unless your company approves the storage provider and retention policy.
- Use a unique long portal password. Do not reuse your email, Google, or WhatsApp password.
- Keep the Supabase service-role key private. It must only be set as a server environment variable, never in browser code or GitHub.
- The starter does not currently auto-delete old images. Delete them from Supabase Storage when no longer required.

## Setup overview

1. Create a Supabase project at https://supabase.com/.
2. In Storage, create a bucket named `office-photos`. Set it to **Private** (not public).
3. In Project Settings → API, copy the Project URL and `service_role` key. Keep the service-role key secret.
4. Deploy this Node project to a Node hosting service (for example, Render) and set the environment variables from `.env.example`.
5. Set `NODE_ENV=production`, a long random `SESSION_SECRET` (32+ characters), and a strong `PORTAL_PASSWORD`.
6. Open the deployed HTTPS address on your phone and office PC. Enter the portal password on each device. Upload from phone; refresh/download on PC.

## Run locally for testing

- Install Node.js 20 or later.
- Copy `.env.example` to `.env` and fill in the values.
- Run `npm install`, then `npm start`.
- Open `http://localhost:3000`.

## Current limits

- Maximum 12 files per upload; maximum file size is configured by `MAX_FILE_MB` (default 20 MB).
- Supported types: JPEG, PNG, WEBP, HEIC, HEIF.
- Login session lasts 12 hours.
- Signed download links last 10 minutes.
- The app lists the most recent 100 files (stored in date folders).
- This is a starter MVP, not an audited enterprise security product. Add company-approved retention, access logging, malware scanning, and stronger identity controls before business-critical deployment.

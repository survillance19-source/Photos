import express from "express";
import helmet from "helmet";
import multer from "multer";
import rateLimit from "express-rate-limit";
import { createClient } from "@supabase/supabase-js";
import crypto from "node:crypto";
import path from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
app.set("trust proxy", 1);
app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: "20kb" }));
app.use(express.static(path.join(__dirname, "public")));

const {
  PORT = 3000, PORTAL_PASSWORD, SESSION_SECRET,
  SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY,
  SUPABASE_BUCKET = "office-photos", MAX_FILE_MB = "20"
} = process.env;

const missing = ["PORTAL_PASSWORD","SESSION_SECRET","SUPABASE_URL","SUPABASE_SERVICE_ROLE_KEY"]
  .filter(k => !process.env[k]);
if (missing.length) {
  console.error("Missing environment variables:", missing.join(", "));
  process.exit(1);
}
if (SESSION_SECRET.length < 32) {
  console.error("SESSION_SECRET must be at least 32 characters.");
  process.exit(1);
}

const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY, {
  auth: { persistSession: false, autoRefreshToken: false }
});
const MAX_BYTES = Math.max(1, Number(MAX_FILE_MB)) * 1024 * 1024;
const allowed = new Set(["image/jpeg","image/png","image/webp","image/heic","image/heif"]);

function sign(value) {
  return crypto.createHmac("sha256", SESSION_SECRET).update(value).digest("base64url");
}
function makeToken() {
  const payload = Buffer.from(JSON.stringify({ exp: Date.now() + 12 * 60 * 60 * 1000 })).toString("base64url");
  return `${payload}.${sign(payload)}`;
}
function validToken(token) {
  if (!token || typeof token !== "string") return false;
  const parts = token.split(".");
  if (parts.length !== 2) return false;
  const expected = Buffer.from(sign(parts[0]));
  const actual = Buffer.from(parts[1]);
  if (expected.length !== actual.length || !crypto.timingSafeEqual(expected, actual)) return false;
  try { return JSON.parse(Buffer.from(parts[0], "base64url").toString()).exp > Date.now(); }
  catch { return false; }
}
function requireAuth(req, res, next) {
  if (!validToken(req.cookiesToken)) return res.status(401).json({ error: "Please unlock the portal again." });
  next();
}
// Read only the dedicated cookie; no third-party account login is involved.
app.use((req, _res, next) => {
  const raw = req.headers.cookie || "";
  const match = raw.split(";").map(v => v.trim()).find(v => v.startsWith("photo_portal="));
  req.cookiesToken = match ? decodeURIComponent(match.slice("photo_portal=".length)) : "";
  next();
});

const loginLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 8, standardHeaders: "draft-8", legacyHeaders: false });
app.post("/api/login", loginLimiter, (req, res) => {
  const supplied = String(req.body?.password || "");
  const a = Buffer.from(supplied);
  const b = Buffer.from(PORTAL_PASSWORD);
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) {
    return res.status(401).json({ error: "Incorrect password." });
  }
  res.cookie("photo_portal", makeToken(), {
    httpOnly: true, secure: process.env.NODE_ENV === "production",
    sameSite: "strict", maxAge: 12 * 60 * 60 * 1000, path: "/"
  });
  res.json({ ok: true });
});
app.post("/api/logout", (_req, res) => {
  res.clearCookie("photo_portal", { httpOnly: true, sameSite: "strict", path: "/" });
  res.json({ ok: true });
});
app.get("/api/me", (req, res) => res.json({ authenticated: validToken(req.cookiesToken) }));

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: MAX_BYTES, files: 12 },
  fileFilter: (_req, file, cb) => cb(null, allowed.has(file.mimetype))
});
app.post("/api/upload", requireAuth, upload.array("photos", 12), async (req, res) => {
  try {
    if (!req.files?.length) return res.status(400).json({ error: "Choose at least one supported image." });
    const results = [];
    for (const file of req.files) {
      const ext = ({ "image/jpeg":"jpg", "image/png":"png", "image/webp":"webp",
        "image/heic":"heic", "image/heif":"heif" })[file.mimetype];
      const objectName = `${new Date().toISOString().slice(0,10)}/${crypto.randomUUID()}.${ext}`;
      const { error } = await supabase.storage.from(SUPABASE_BUCKET)
        .upload(objectName, file.buffer, { contentType: file.mimetype, upsert: false });
      if (error) throw error;
      results.push({ name: file.originalname, path: objectName, size: file.size });
    }
    res.json({ ok: true, uploaded: results.length });
  } catch (err) {
    console.error("Upload failed:", err.message);
    res.status(500).json({ error: "Upload failed. Check storage setup and try again." });
  }
});
app.get("/api/files", requireAuth, async (_req, res) => {
  try {
    const { data, error } = await supabase.storage.from(SUPABASE_BUCKET).list("", {
      limit: 100, sortBy: { column: "name", order: "desc" }
    });
    if (error) throw error;
    // Files are stored in date folders; list folders, then list their contents.
    const output = [];
    for (const folder of (data || []).filter(x => !x.id)) {
      const { data: children, error: childError } = await supabase.storage.from(SUPABASE_BUCKET)
        .list(folder.name, { limit: 100, sortBy: { column: "name", order: "desc" } });
      if (childError) throw childError;
      for (const item of children || []) {
        if (!item.id) continue;
        const objectPath = `${folder.name}/${item.name}`;
        const { data: signed, error: signedError } = await supabase.storage.from(SUPABASE_BUCKET)
          .createSignedUrl(objectPath, 60 * 10);
        if (signedError) throw signedError;
        output.push({ name: item.name, path: objectPath, createdAt: item.created_at, url: signed.signedUrl });
      }
    }
    output.sort((a,b) => (b.createdAt || "").localeCompare(a.createdAt || ""));
    res.json({ files: output.slice(0, 100) });
  } catch (err) {
    console.error("List failed:", err.message);
    res.status(500).json({ error: "Could not load images." });
  }
});
app.get("/health", (_req,res) => res.json({ ok: true }));
app.listen(PORT, () => console.log(`Private Photo Transfer running on port ${PORT}`));
